﻿Imports System.Data.SqlClient

Public Class Form1

    Dim conexao As New SqlConnection("Data Source=DESKTOP-PPMHDVC\SQLEXPRESS;Initial Catalog=SistemaAlimentos;Integrated Security=True")

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbCategoria.Items.Add("Bebidas")
        cbCategoria.Items.Add("Grãos")
        cbCategoria.Items.Add("Laticínios")
        cbCategoria.Items.Add("Carnes")
        cbCategoria.Items.Add("Frutas")

        CarregarDados()
    End Sub

    Sub CarregarDados()
        Try
            conexao.Open()

            Dim cmd As New SqlCommand("SELECT * FROM Produtos", conexao)
            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()

            da.Fill(dt)
            DataGridView1.DataSource = dt

            conexao.Close()
        Catch ex As Exception
            MessageBox.Show("Erro ao carregar dados")
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnSalvar.Click
        Try
            conexao.Open()

            Dim sql As String = "INSERT INTO Produtos(Produto, Categoria, Marca, Fornecedor, Quantidade, PrecoCusto, PrecoVenda, Margem) VALUES(@Produto, @Categoria, @Marca, @Fornecedor, @Quantidade, @PrecoCusto, @PrecoVenda, @Margem)"

            Dim cmd As New SqlCommand(sql, conexao)

            cmd.Parameters.AddWithValue("@Produto", txtProduto.Text)
            cmd.Parameters.AddWithValue("@Categoria", cbCategoria.Text)
            cmd.Parameters.AddWithValue("@Marca", txtMarca.Text)
            cmd.Parameters.AddWithValue("@Fornecedor", txtFornecedor.Text)
            cmd.Parameters.AddWithValue("@Quantidade", Convert.ToInt32(txtQtd.Text))
            cmd.Parameters.AddWithValue("@PrecoCusto", Convert.ToDecimal(txtPrecoCusto.Text))
            cmd.Parameters.AddWithValue("@PrecoVenda", Convert.ToDecimal(txtPrecoVenda.Text))

            Dim margem As Double = ((Convert.ToDouble(txtPrecoVenda.Text) - Convert.ToDouble(txtPrecoCusto.Text)) / Convert.ToDouble(txtPrecoCusto.Text)) * 100

            cmd.Parameters.AddWithValue("@Margem", margem)

            cmd.ExecuteNonQuery()
            conexao.Close()

            MessageBox.Show("Produto salvo")

            CarregarDados()

        Catch ex As Exception
            MessageBox.Show("Erro ao salvar:" & ex.Message)
            conexao.Close

        End Try
    End Sub

    Private Sub btnCalcularMargem_Click(sender As Object, e As EventArgs) Handles btnCalcularMargem.Click
        Try
            Dim custo As Double = Convert.ToDouble(txtPrecoCusto.Text)
            Dim venda As Double = Convert.ToDouble(txtPrecoVenda.Text)

            Dim margem As Double = ((venda - custo) / custo) * 100

            txtMargem.Text = margem.ToString("F2") & "%"
        Catch ex As Exception
            MessageBox.Show("Erro no cáculo")

        End Try
    End Sub

    Private Sub btnLimpar_Click(sender As Object, e As EventArgs) Handles btnLimpar.Click
        Try
            If DataGridView1.CurrentRow Is Nothing Then
                MessageBox.Show("Selecione um registro")
                Exit Sub
            End If

            Dim id As Integer = DataGridView1.CurrentRow.Cells("id").Value

            conexao.Open()

            Dim cmd As New SqlCommand("DELETE FROM Produtos WHERE id = @id", conexao)
            cmd.Parameters.AddWithValue("@id", id)

            cmd.ExecuteNonQuery()
            conexao.Close()

            MessageBox.Show("Registro excluido")

            CarregarDados()
        Catch ex As Exception
            MessageBox.Show("Erro:" & ex.Message)
            conexao.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        DataGridView1.AutoGenerateColumns = False
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim abrir As New OpenFileDialog()

        abrir.Title = "Selecione imagem"
        abrir.Filter = "Imagens|*.jpg;*.jpeg;*.png"

        If abrir.ShowDialog() = DialogResult.OK Then
            PictureBox1.Image = Image.FromFile(abrir.FileName)
        End If
    End Sub
End Class
