﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtProduto = New TextBox()
        txtMarca = New TextBox()
        txtFornecedor = New TextBox()
        txtQtd = New TextBox()
        txtPrecoCusto = New TextBox()
        txtPrecoVenda = New TextBox()
        txtMargem = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        cbCategoria = New ComboBox()
        PictureBox1 = New PictureBox()
        DataGridView1 = New DataGridView()
        btnCalcularMargem = New Button()
        btnSalvar = New Button()
        btnLimpar = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtProduto
        ' 
        txtProduto.Location = New Point(12, 36)
        txtProduto.Name = "txtProduto"
        txtProduto.Size = New Size(100, 23)
        txtProduto.TabIndex = 0
        ' 
        ' txtMarca
        ' 
        txtMarca.Location = New Point(12, 93)
        txtMarca.Name = "txtMarca"
        txtMarca.Size = New Size(100, 23)
        txtMarca.TabIndex = 1
        ' 
        ' txtFornecedor
        ' 
        txtFornecedor.Location = New Point(12, 153)
        txtFornecedor.Name = "txtFornecedor"
        txtFornecedor.Size = New Size(100, 23)
        txtFornecedor.TabIndex = 2
        ' 
        ' txtQtd
        ' 
        txtQtd.Location = New Point(205, 36)
        txtQtd.Name = "txtQtd"
        txtQtd.Size = New Size(100, 23)
        txtQtd.TabIndex = 3
        ' 
        ' txtPrecoCusto
        ' 
        txtPrecoCusto.Location = New Point(205, 93)
        txtPrecoCusto.Name = "txtPrecoCusto"
        txtPrecoCusto.Size = New Size(100, 23)
        txtPrecoCusto.TabIndex = 4
        ' 
        ' txtPrecoVenda
        ' 
        txtPrecoVenda.Location = New Point(205, 153)
        txtPrecoVenda.Name = "txtPrecoVenda"
        txtPrecoVenda.Size = New Size(100, 23)
        txtPrecoVenda.TabIndex = 5
        ' 
        ' txtMargem
        ' 
        txtMargem.Location = New Point(379, 36)
        txtMargem.Name = "txtMargem"
        txtMargem.ReadOnly = True
        txtMargem.Size = New Size(100, 23)
        txtMargem.TabIndex = 6
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 18)
        Label1.Name = "Label1"
        Label1.Size = New Size(50, 15)
        Label1.TabIndex = 7
        Label1.Text = "Produto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 75)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 15)
        Label2.TabIndex = 8
        Label2.Text = "Marca"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 135)
        Label3.Name = "Label3"
        Label3.Size = New Size(67, 15)
        Label3.TabIndex = 9
        Label3.Text = "Fornecedor"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(205, 18)
        Label4.Name = "Label4"
        Label4.Size = New Size(69, 15)
        Label4.TabIndex = 10
        Label4.Text = "Quantidade"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(205, 75)
        Label5.Name = "Label5"
        Label5.Size = New Size(71, 15)
        Label5.TabIndex = 11
        Label5.Text = "Preço Custo"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(205, 135)
        Label6.Name = "Label6"
        Label6.Size = New Size(72, 15)
        Label6.TabIndex = 12
        Label6.Text = "Preço Venda"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(379, 18)
        Label7.Name = "Label7"
        Label7.Size = New Size(52, 15)
        Label7.TabIndex = 13
        Label7.Text = "Margem"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(379, 75)
        Label8.Name = "Label8"
        Label8.Size = New Size(58, 15)
        Label8.TabIndex = 14
        Label8.Text = "Categoria"
        ' 
        ' cbCategoria
        ' 
        cbCategoria.FormattingEnabled = True
        cbCategoria.Location = New Point(379, 93)
        cbCategoria.Name = "cbCategoria"
        cbCategoria.Size = New Size(121, 23)
        cbCategoria.TabIndex = 15
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = My.Resources.Resources.Produto
        PictureBox1.Image = My.Resources.Resources.Produto
        PictureBox1.Location = New Point(873, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(156, 160)
        PictureBox1.TabIndex = 16
        PictureBox1.TabStop = False
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 215)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(843, 150)
        DataGridView1.TabIndex = 17
        ' 
        ' btnCalcularMargem
        ' 
        btnCalcularMargem.Location = New Point(873, 178)
        btnCalcularMargem.Name = "btnCalcularMargem"
        btnCalcularMargem.Size = New Size(64, 31)
        btnCalcularMargem.TabIndex = 18
        btnCalcularMargem.Text = "Margem"
        btnCalcularMargem.UseVisualStyleBackColor = True
        ' 
        ' btnSalvar
        ' 
        btnSalvar.Location = New Point(965, 178)
        btnSalvar.Name = "btnSalvar"
        btnSalvar.Size = New Size(64, 31)
        btnSalvar.TabIndex = 19
        btnSalvar.Text = "Salvar"
        btnSalvar.UseVisualStyleBackColor = True
        ' 
        ' btnLimpar
        ' 
        btnLimpar.Location = New Point(965, 215)
        btnLimpar.Name = "btnLimpar"
        btnLimpar.Size = New Size(64, 31)
        btnLimpar.TabIndex = 20
        btnLimpar.Text = "Limpar"
        btnLimpar.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1041, 450)
        Controls.Add(btnLimpar)
        Controls.Add(btnSalvar)
        Controls.Add(btnCalcularMargem)
        Controls.Add(DataGridView1)
        Controls.Add(PictureBox1)
        Controls.Add(cbCategoria)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtMargem)
        Controls.Add(txtPrecoVenda)
        Controls.Add(txtPrecoCusto)
        Controls.Add(txtQtd)
        Controls.Add(txtFornecedor)
        Controls.Add(txtMarca)
        Controls.Add(txtProduto)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtProduto As TextBox
    Friend WithEvents txtMarca As TextBox
    Friend WithEvents txtFornecedor As TextBox
    Friend WithEvents txtQtd As TextBox
    Friend WithEvents txtPrecoCusto As TextBox
    Friend WithEvents txtPrecoVenda As TextBox
    Friend WithEvents txtMargem As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents cbCategoria As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnCalcularMargem As Button
    Friend WithEvents btnSalvar As Button
    Friend WithEvents btnLimpar As Button

End Class
